package com.example.demo.exceptionHandler.suppliers;

public class SuppliersNotFoundException extends Exception {
 public SuppliersNotFoundException(String message) {
	 super(message);
 }
}
