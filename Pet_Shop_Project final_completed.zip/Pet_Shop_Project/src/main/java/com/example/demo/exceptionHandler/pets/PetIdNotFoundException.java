package com.example.demo.exceptionHandler.pets;

public class PetIdNotFoundException extends Exception{
	public PetIdNotFoundException(String message) {
	super(message);
	}
}
