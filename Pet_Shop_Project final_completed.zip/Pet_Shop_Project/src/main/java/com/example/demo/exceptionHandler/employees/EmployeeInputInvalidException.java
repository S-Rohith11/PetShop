package com.example.demo.exceptionHandler.employees;

public class EmployeeInputInvalidException extends Exception{
	public EmployeeInputInvalidException(String message) {
		super(message);
	}

}





