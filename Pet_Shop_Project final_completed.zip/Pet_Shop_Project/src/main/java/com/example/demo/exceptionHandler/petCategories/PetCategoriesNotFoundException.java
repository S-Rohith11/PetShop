package com.example.demo.exceptionHandler.petCategories;

public class PetCategoriesNotFoundException extends Exception {

	public PetCategoriesNotFoundException(String message) {
		 super(message);
	 }
	
}
