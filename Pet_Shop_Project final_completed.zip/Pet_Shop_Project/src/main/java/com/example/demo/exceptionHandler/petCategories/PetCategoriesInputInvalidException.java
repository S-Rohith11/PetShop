package com.example.demo.exceptionHandler.petCategories;

public class PetCategoriesInputInvalidException  extends Exception{
 public PetCategoriesInputInvalidException(String message) {
	 super(message);
 }
}
