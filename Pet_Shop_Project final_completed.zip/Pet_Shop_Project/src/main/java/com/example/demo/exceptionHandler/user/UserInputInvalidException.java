package com.example.demo.exceptionHandler.user;

public class UserInputInvalidException extends Exception {
public UserInputInvalidException(String message) {
	super(message);
}
}
