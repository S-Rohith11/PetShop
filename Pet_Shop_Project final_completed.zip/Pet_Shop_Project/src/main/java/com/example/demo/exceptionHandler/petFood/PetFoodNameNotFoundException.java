package com.example.demo.exceptionHandler.petFood;

public class PetFoodNameNotFoundException extends Exception { 
	public PetFoodNameNotFoundException(String message) {
		super(message);
	}

}



