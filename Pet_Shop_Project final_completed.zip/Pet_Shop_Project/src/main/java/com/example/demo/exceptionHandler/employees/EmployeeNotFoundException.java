package com.example.demo.exceptionHandler.employees;

public class EmployeeNotFoundException extends Exception { 
	public EmployeeNotFoundException(String message) {
		super(message);
	}

}




