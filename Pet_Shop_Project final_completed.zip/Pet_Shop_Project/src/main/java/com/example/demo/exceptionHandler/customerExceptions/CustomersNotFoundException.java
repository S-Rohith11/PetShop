package com.example.demo.exceptionHandler.customerExceptions;

public class CustomersNotFoundException extends Exception{
	public  CustomersNotFoundException(String str) {
		super(str);
	}

}
