package com.example.demo.exceptionHandler.suppliers;

public class SupplierNotFoundByCityException  extends Exception{
 public SupplierNotFoundByCityException(String message) {
	 super(message);
 }
}
