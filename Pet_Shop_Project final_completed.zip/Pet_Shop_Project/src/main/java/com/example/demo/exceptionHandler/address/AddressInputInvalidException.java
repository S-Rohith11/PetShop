package com.example.demo.exceptionHandler.address;


public class AddressInputInvalidException  extends Exception{
	 public AddressInputInvalidException(String message) {
		 super(message);
	 }
}