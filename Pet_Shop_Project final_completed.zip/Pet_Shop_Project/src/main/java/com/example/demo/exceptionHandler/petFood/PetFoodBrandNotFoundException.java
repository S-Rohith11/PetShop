package com.example.demo.exceptionHandler.petFood;

public class PetFoodBrandNotFoundException extends Exception { 
	public PetFoodBrandNotFoundException(String message) {
		super(message);
	}

}



