package com.example.demo.exceptionHandler.petFood;

public class PetFoodIdNotFoundException extends Exception{ 
	public PetFoodIdNotFoundException(String message) {
		super(message);
	}

}


