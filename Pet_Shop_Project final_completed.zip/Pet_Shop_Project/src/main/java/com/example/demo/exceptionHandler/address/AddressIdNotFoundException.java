package com.example.demo.exceptionHandler.address;

public class AddressIdNotFoundException  extends Exception{
	 public AddressIdNotFoundException(String message) {
		 super(message);
	 }
}