package com.example.demo.exceptionHandler.suppliers;

public class SupplierInputInvalidException  extends Exception{
 public SupplierInputInvalidException(String message) {
	 super(message);
 }
}
