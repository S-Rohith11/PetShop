package com.example.demo.exceptionHandler.petFood;

public class FoodInputInvalidException extends Exception {
	public FoodInputInvalidException(String message) {
		super(message);
	}

}


