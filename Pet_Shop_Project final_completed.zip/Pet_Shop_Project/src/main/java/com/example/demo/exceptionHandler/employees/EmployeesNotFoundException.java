package com.example.demo.exceptionHandler.employees;

public class EmployeesNotFoundException extends Exception {
	public EmployeesNotFoundException(String message) {
		super(message);
	}

}



