package com.example.demo.exceptionHandler.petFood;

public class NoPetFoodFoundException extends Exception {
	public NoPetFoodFoundException(String message) {
		super(message);
	}

}


