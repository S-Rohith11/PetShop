package com.example.demo.exceptionHandler.address;

public class AddressNotFoundException  extends Exception{
	 public AddressNotFoundException(String message) {
		 super(message);
	 }
}