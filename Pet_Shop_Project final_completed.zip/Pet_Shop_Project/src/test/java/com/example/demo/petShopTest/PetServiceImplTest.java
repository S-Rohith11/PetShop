package com.example.demo.petShopTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
	import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
	import static org.junit.jupiter.api.Assertions.assertThrows;
	import static org.mockito.Mockito.when;
	import java.util.ArrayList;
	import java.util.List;
	import java.util.NoSuchElementException;
	import java.util.Optional;
	import org.junit.jupiter.api.BeforeEach;
	import org.junit.jupiter.api.Test;
	import org.junit.jupiter.api.extension.ExtendWith;
	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.MockitoAnnotations;
	import org.mockito.junit.jupiter.MockitoExtension;
	import org.springframework.boot.test.context.SpringBootTest;
	import org.springframework.data.repository.CrudRepository;
	import com.example.demo.*;
import com.example.demo.entity.Pets;
import com.example.demo.exceptionHandler.pets.PetCategoryNotFoundException;
import com.example.demo.exceptionHandler.pets.PetIdNotFoundException;
import com.example.demo.exceptionHandler.pets.PetsNotFoundException;
import com.example.demo.repository.PetCategoriesRepository;
	import com.example.demo.repository.PetsRepository;
	import com.example.demo.service.PetServiceImpl;
   @ExtendWith(MockitoExtension.class)
	public class PetServiceImplTest {
	    private static final CrudRepository<Pets, Integer> petRepository = null;
		@Mock
	    private PetsRepository petsRepository; // Mocked repository for Pets and PetCategories
	    @Mock
	    private PetCategoriesRepository petCategoriesRepository;
	    @InjectMocks
	    private PetServiceImpl petService;
	    @BeforeEach
	    public void setUp() {
	        MockitoAnnotations.initMocks(this); // Initialize mocks before each test
	    }
	    @Test
	    public void testRetrieveAllPets() {
	        List<Pets> petsList = new ArrayList<>();
	        petsList.add(new Pets()); // Adding a mock Pet object to the list
	        
	     // Mock repository behavior to return a list of pets
	        when(petsRepository.findAll()).thenReturn(petsList);
	        assertDoesNotThrow(() -> petService.getAllPets()); // Ensure no exceptions are thrown
	    }
	    @Test
	    public void getAllPets_PetsNotFoundException() {
	    	// Mock repository to return an empty list indicating no pets found
	        when(petsRepository.findAll()).thenReturn(new ArrayList<>());
	        assertThrows(PetsNotFoundException.class, () -> petService.getAllPets()); // Ensure PetsNotFoundException is thrown
	    }
	    @Test
	    public void testRetrieveById() {
	        Pets pet = new Pets();
	        //pet.setId(1);
	        Optional<Pets> optionalPet = Optional.of(pet);
	        
	     // Mock Pet object wrapped in Optional
	     // Mock repository behavior to return a pet by ID
	        when(petsRepository.findById(1)).thenReturn(optionalPet);
	        assertDoesNotThrow(() -> petService.getPetsById(1)); // Ensure no exceptions are thrown
	    }
	    @Test
	    public void testRetrieveById_PetIdNotFoundException() {
	    	// Mock repository to throw NoSuchElementException when looking up a pet by ID
	        when(petsRepository.findById(1)).thenThrow(NoSuchElementException.class);
	        assertThrows(PetIdNotFoundException.class, () -> petService.getPetsById(1));// Ensure PetIdNotFoundException is thrown
	    }
	    @Test
	    public void testGetPetsByCategory() {
	        List<Pets> petsList = new ArrayList<>();
	        petsList.add(new Pets());
	     // Adding a mock Pet object to the list
	        
	        // Mock repository behavior to return a list of pets by category
	        when(petsRepository.findByCategoryName("Category")).thenReturn(petsList);
	        assertDoesNotThrow(() -> petService.getPetsByCategory("Category"));
	     // Ensure no exceptions are thrown
	    }
	    @Test
	    public void testGetPetsByCategory_PetCategoryNotFoundException() {
	    	 
	    	// Mock repository to return an empty list indicating no pets found for the given category
	        when(petsRepository.findByCategoryName("Category")).thenReturn(new ArrayList<>());
	        assertThrows(PetCategoryNotFoundException.class, () -> petService.getPetsByCategory("Category"));
	     // Ensure PetCategoryNotFoundException is thrown
	    }
	    }


	